import pymysql

def db():
    con=pymysql.Connect(host='localhost',user='root',password='',db='employees',port=3306)
    cu=con.cursor()
    return con,cu