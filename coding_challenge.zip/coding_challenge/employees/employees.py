from flask import Flask,render_template,request,redirect,url_for
from da import db

app = Flask(__name__)
app.secret_key="hai"

@app.route('/')
def load():
    return render_template("home.html")
@app.route('/addemp')
def addemp():
    return render_template("addemployee.html")
@app.route('/back')
def back():
    return render_template("home.html")
@app.route('/ereg',methods=["post"])
def ereg():
    a = request.form['t1']
    b = request.form['t2']
    c = request.form['t3']
    d = request.form['t4']
    insert = "insert into empreg(name,designation,adress,phone)VALUES('"+a+"','"+b+"','"+c+"','"+d+"')"
    print(insert)
    con, cu =db()
    cu.execute(insert)
    con.commit()
    return render_template("addemployee.html")
@app.route('/listemp')
def listemp():

    x="select * from empreg"
    con,cu=db()
    cu.execute(x)
    ff=cu.fetchall()

    print(x)
    return render_template("listofemployees.html",ff=ff)
@app.route('/delete/<id>')
def d(id):
    aa="delete from empreg where eid='"+id+"'"
    con,cu=db()
    cu.execute(aa)
    con.commit()
    return redirect(url_for('listemp'))
@app.route('/search',methods=['post'])
def search():

    a=request.form['tt']
    y="select * from empreg where name='"+a+"' or designation='"+a+"' or phone='"+a+"'"
    con, cu = db()
    cu.execute(y)

    ff = cu.fetchall()
    return render_template("result.html", ff=ff)

if __name__ == '__main__':
    app.run(port=54646,debug=True)
